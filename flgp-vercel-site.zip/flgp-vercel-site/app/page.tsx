import { ArrowRight, BarChart3, CheckCircle2, Mail, Phone, Target, Workflow, Users } from 'lucide-react';

function SectionCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-[24px] border border-slate-200 bg-white shadow-sm ${className}`}>{children}</div>;
}

export default function HomePage() {
  const navItems = [
    { label: 'Services', href: '#services' },
    { label: 'Results', href: '#results' },
    { label: 'Process', href: '#process' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  const services = [
    {
      icon: Target,
      title: 'Lead Generation',
      description:
        'Build a more predictable pipeline with positioning, campaigns, funnels, and intake systems designed for family law growth.',
    },
    {
      icon: Users,
      title: 'Sales Optimization',
      description:
        'Improve consult booking, show rates, follow-up, and close rates with a disciplined lead-to-signed-client process.',
    },
    {
      icon: Workflow,
      title: 'Operational Systems',
      description:
        'Install SOPs, scorecards, accountability rhythms, and delivery systems so growth does not create chaos.',
    },
    {
      icon: BarChart3,
      title: 'Revenue Visibility',
      description:
        'Track CAC, conversion, pipeline health, retained revenue, and bottlenecks so decisions are driven by numbers.',
    },
  ];

  const outcomes = [
    'Clear revenue funnel from lead → consult → show → close',
    'Faster follow-up and tighter intake execution',
    'More signed clients without adding unnecessary headcount',
    'Better visibility into marketing ROI and sales performance',
  ];

  const steps = [
    {
      step: '01',
      title: 'Diagnose the bottleneck',
      description:
        'We identify where revenue is leaking across marketing, intake, sales, and client delivery.',
    },
    {
      step: '02',
      title: 'Install the operating system',
      description:
        'We build the scorecards, SOPs, reporting, and accountability structure your team actually uses.',
    },
    {
      step: '03',
      title: 'Drive weekly execution',
      description:
        'We help your team improve the numbers that matter with focused weekly priorities and owner accountability.',
    },
  ];

  const metrics = [
    { label: 'Pipeline Clarity', value: '100%' },
    { label: 'Execution Focus', value: 'Weekly' },
    { label: 'Primary KPI View', value: 'Lead → Close' },
  ];

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-8">
          <a href="#top" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-900 text-sm font-bold text-white">
              FL
            </div>
            <div>
              <div className="text-sm font-semibold tracking-wide text-slate-900">
                Family Law Growth Partners
              </div>
              <div className="text-xs text-slate-500">Growth systems for family law firms</div>
            </div>
          </a>

          <nav className="hidden items-center gap-8 md:flex">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-sm font-medium text-slate-600 transition hover:text-slate-900"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <a
            href="#contact"
            className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white"
          >
            Book a Strategy Call
          </a>
        </div>
      </header>

      <main id="top">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-100 via-white to-slate-50" />
          <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-2 lg:px-8 lg:py-28">
            <div className="flex flex-col justify-center">
              <div className="mb-6 inline-flex w-fit items-center rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-slate-600 shadow-sm">
                Consulting for growth-minded family law firms
              </div>
              <h1 className="max-w-2xl text-4xl font-bold leading-tight tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
                Turn marketing, intake, and operations into a predictable growth engine.
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">
                Family Law Growth Partners helps family law firms fix the bottlenecks between lead generation,
                consults, signed clients, and scalable delivery.
              </p>
              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <a
                  href="#contact"
                  className="inline-flex items-center justify-center rounded-2xl bg-slate-900 px-6 py-4 text-base font-semibold text-white"
                >
                  Book a Strategy Call <ArrowRight className="ml-2 h-4 w-4" />
                </a>
                <a
                  href="#services"
                  className="inline-flex items-center justify-center rounded-2xl border border-slate-300 px-6 py-4 text-base font-semibold text-slate-900"
                >
                  See How We Work
                </a>
              </div>
              <div className="mt-10 grid gap-4 sm:grid-cols-3">
                {metrics.map((metric) => (
                  <SectionCard key={metric.label}>
                    <div className="p-5">
                      <div className="text-2xl font-bold text-slate-950">{metric.value}</div>
                      <div className="mt-1 text-sm text-slate-500">{metric.label}</div>
                    </div>
                  </SectionCard>
                ))}
              </div>
            </div>

            <div className="flex items-center">
              <div className="w-full rounded-[28px] border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
                <div className="p-8">
                  <div className="mb-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Core Focus</p>
                      <h2 className="mt-2 text-2xl font-bold text-slate-950">Fix the numbers that drive revenue</h2>
                    </div>
                    <div className="rounded-2xl bg-slate-100 p-3">
                      <BarChart3 className="h-6 w-6 text-slate-900" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    {[
                      ['Lead flow', 'Consistent demand from the right cases'],
                      ['Consult conversion', 'Higher booking and show rates'],
                      ['Sales discipline', 'Better follow-up and close rates'],
                      ['Operational capacity', 'Delivery systems that support growth'],
                    ].map(([title, text]) => (
                      <div key={title} className="flex items-start gap-3 rounded-2xl border border-slate-200 p-4">
                        <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-slate-900" />
                        <div>
                          <div className="font-semibold text-slate-900">{title}</div>
                          <div className="text-sm leading-6 text-slate-600">{text}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Services</p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
              Built to improve the entire revenue system, not just one piece of it.
            </h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <SectionCard key={service.title} className="transition hover:-translate-y-1 hover:shadow-lg">
                  <div className="p-6">
                    <div className="mb-5 inline-flex rounded-2xl bg-slate-100 p-3">
                      <Icon className="h-6 w-6 text-slate-900" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-950">{service.title}</h3>
                    <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
                  </div>
                </SectionCard>
              );
            })}
          </div>
        </section>

        <section id="results" className="bg-slate-950 py-20 text-white">
          <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-2 lg:px-8">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-400">What clients want</p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
                Better numbers. Better execution. Better growth decisions.
              </h2>
            </div>
            <div className="grid gap-4">
              {outcomes.map((outcome) => (
                <div key={outcome} className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" />
                  <p className="text-sm leading-7 text-slate-200">{outcome}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="process" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Process</p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
              A simple operating model that creates traction fast.
            </h2>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {steps.map((item) => (
              <SectionCard key={item.step}>
                <div className="p-8">
                  <div className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Step {item.step}</div>
                  <h3 className="mt-4 text-2xl font-bold text-slate-950">{item.title}</h3>
                  <p className="mt-4 text-sm leading-7 text-slate-600">{item.description}</p>
                </div>
              </SectionCard>
            ))}
          </div>
        </section>

        <section id="about" className="bg-slate-50 py-20">
          <div className="mx-auto grid max-w-7xl gap-10 px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">About</p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
                We help family law firms grow with operational discipline.
              </h2>
              <p className="mt-6 max-w-2xl text-base leading-8 text-slate-600">
                Most firms do not have a lead problem alone. They have a system problem. Revenue gets lost in weak
                follow-up, poor visibility, unclear ownership, inconsistent intake, and delivery strain. We fix those
                gaps so growth becomes more predictable.
              </p>
            </div>
            <SectionCard className="rounded-[28px]">
              <div className="p-8">
                <h3 className="text-xl font-bold text-slate-950">What makes this different</h3>
                <div className="mt-6 space-y-4 text-sm leading-7 text-slate-600">
                  <p>We focus on the metrics that actually determine signed clients and retained revenue.</p>
                  <p>We build systems your team can run every week, not ideas that die in a document.</p>
                  <p>We push for accountability, ownership, and measurable execution across the entire funnel.</p>
                </div>
              </div>
            </SectionCard>
          </div>
        </section>

        <section id="contact" className="mx-auto max-w-4xl px-6 py-20 lg:px-8">
          <div className="rounded-[32px] border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
            <div className="p-8 sm:p-10">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Contact</p>
                <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
                  Ready to tighten the funnel and grow revenue?
                </h2>
                <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-slate-600">
                  Replace the placeholder contact details below with your real info, calendar link, or embedded form.
                </p>
              </div>

              <div className="mt-10 grid gap-6 md:grid-cols-2">
                <div className="rounded-2xl border border-slate-200 p-6">
                  <div className="flex items-center gap-3 text-slate-900">
                    <Mail className="h-5 w-5" />
                    <span className="font-semibold">Email</span>
                  </div>
                  <p className="mt-3 text-sm text-slate-600">hello@familylawgrowthpartners.com</p>
                </div>
                <div className="rounded-2xl border border-slate-200 p-6">
                  <div className="flex items-center gap-3 text-slate-900">
                    <Phone className="h-5 w-5" />
                    <span className="font-semibold">Phone</span>
                  </div>
                  <p className="mt-3 text-sm text-slate-600">(555) 555-5555</p>
                </div>
              </div>

              <div className="mt-8 flex justify-center">
                <a
                  href="mailto:hello@familylawgrowthpartners.com"
                  className="inline-flex items-center justify-center rounded-2xl bg-slate-900 px-6 py-4 text-base font-semibold text-white"
                >
                  Start the Conversation
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-6 py-8 text-sm text-slate-500 md:flex-row md:items-center md:justify-between lg:px-8">
          <p>© 2026 Family Law Growth Partners. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#services" className="transition hover:text-slate-900">Services</a>
            <a href="#about" className="transition hover:text-slate-900">About</a>
            <a href="#contact" className="transition hover:text-slate-900">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}